#include "OpenCV.h"

class Constants: public node::ObjectWrap {
 public:
    static void Init(Handle<Object> target);
};
